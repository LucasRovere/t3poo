//package item;
//package character;
//package tasks;
package game;

public enum HuntType {

    monster,
    animal
}
