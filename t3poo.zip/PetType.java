//package item;
//package character;
//package tasks;
package game;

public enum PetType {

    wolf,
    tiger,
    lion,
    eagle
}
