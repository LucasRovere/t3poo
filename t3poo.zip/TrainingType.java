
//package item;
//package character;
//package tasks;
package game;

public enum TrainingType {
    run,        //speed
    lift,       //strenght
    fight,      //constitution
    parkour,     //dexterity
    special     //Especifico da classe
}
