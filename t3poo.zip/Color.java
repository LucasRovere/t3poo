package game;
//package item;
//package character;
//package tasks;

public enum Color {

    blue,
    red,
    green,
    yellow,
    white,
    black;
}
