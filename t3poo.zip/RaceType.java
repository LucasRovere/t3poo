
//package item;
//package character;
//package tasks;
package game;

public enum RaceType {
    orc,
    zombie,
    dragon,
    creeper
}
