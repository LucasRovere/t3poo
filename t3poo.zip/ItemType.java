package game;
//package item;
//package character;
//package tasks;

public enum ItemType{
	weapon,
	armor,
	potion,
	generic
}
